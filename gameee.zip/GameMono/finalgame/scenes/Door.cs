using Godot;
using System;

public partial class Door : Area2D
{
	[Export] public NodePath TopExitPath;
	[Export] public NodePath BottomExitPath;

	private Node2D topExit;
	private Node2D bottomExit;

	public override void _Ready()
	{
		if (TopExitPath != null)
			topExit = GetNode<Node2D>(TopExitPath);

		if (BottomExitPath != null)
			bottomExit = GetNode<Node2D>(BottomExitPath);

		this.BodyEntered += OnBodyEntered;
	}

	private void OnBodyEntered(Node body)
	{
		if (body is Player)  // Replace 'Player' with your player class if different
		{
			var transition = GetNode<Transitionn>("/root/Transitionn");
			transition.FadeOut(() =>
			{
				GetTree().ChangeSceneToFile("res://scenes/main2.tscn");
			});
		}
	}
}
