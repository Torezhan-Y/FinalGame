using Godot;

public interface IPlayerState
{
 void HandleInput(Player player);
 void Update(Player player, float delta);
}

public class IdleState : IPlayerState
{
 public void HandleInput(Player player)
 {
  if (Input.IsActionJustPressed("ui_accept") && player.IsOnFloor())
  {
   player.State = new JumpState();
   player.Jump();  // Прыжок при входе в JumpState
  }
  else if (Input.IsActionPressed("ui_down"))
  {
   player.State = new DuckState();
  }
  else if (Input.IsActionPressed("ui_right") || Input.IsActionPressed("ui_left"))
  {
   player.State = new RunState();
  }
 }

 public void Update(Player player, float delta)
 {
  player.PlayAnimation("idle");
 }
}

public class RunState : IPlayerState
{
 private const float SPEED = 600f;

 public void HandleInput(Player player)
 {
  if (Input.IsActionJustPressed("ui_accept") && player.IsOnFloor())
  {
   player.State = new JumpState();
   player.Jump();
  }
  else if (Input.IsActionPressed("ui_down"))
  {
   player.State = new DuckState();
  }
  else if (!Input.IsActionPressed("ui_right") && !Input.IsActionPressed("ui_left"))
  {
   player.State = new IdleState();
  }
 }

 public void Update(Player player, float delta)
 {
  Vector2 velocity = player.Velocity;

  if (Input.IsActionPressed("ui_right"))
  {
   velocity.X = SPEED;
   
  }
  else if (Input.IsActionPressed("ui_left"))
  {
   velocity.X = -SPEED;
   
  }
  else
  {
   velocity.X = 0;
  }

  player.Velocity = velocity;
  player.PlayAnimation("run");
 }
}

public class JumpState : IPlayerState
{
 public void HandleInput(Player player)
 {
  // Если игрок коснулся земли — возвращаемся в Idle
  if (player.IsOnFloor())
  {
   player.State = new IdleState();
  }
 }

 public void Update(Player player, float delta)
 {
  player.PlayAnimation("jump");
  // Гравитация уже в Player._PhysicsProcess, здесь её не трогаем
 }
}

public class DuckState : IPlayerState
{
 public void HandleInput(Player player)
 {
  if (Input.IsActionJustPressed("ui_accept") && player.IsOnFloor())
  {
   player.State = new JumpState();
   player.Jump();
  }
  else if (!Input.IsActionPressed("ui_down"))
  {
   player.State = new IdleState();
  }
 }

 public void Update(Player player, float delta)
 {
  player.PlayAnimation("duck");
  // Игрок остаётся в duck, пока кнопка ui_down нажата
 }
}
