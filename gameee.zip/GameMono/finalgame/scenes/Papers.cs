using Godot;

// Интерфейс перемещения
public interface IMoveStrategy
{
	void Move(Node2D node, double delta);
}

// Реализация прямолинейного движения
public class LinearMoveStrategy : IMoveStrategy
{
	private float _speed;

	public LinearMoveStrategy(float speed)
	{
		_speed = speed;
	}

	public void Move(Node2D node, double delta)
	{
		node.Position -= new Vector2(_speed * (float)delta, 0);
	}
}

// Сам враг/препятствие
public partial class Papers : Area2D
{
	private IMoveStrategy _moveStrategy;

	public override void _Ready()
	{
		float speed = 200f;

		// Если у родителя есть параметр "speed" — взять его
		if (GetParent().HasMeta("speed"))
		{
			speed = (float)(double)GetParent().GetMeta("speed") / 2f;
		}

		_moveStrategy = new LinearMoveStrategy(speed);
	}

	public override void _Process(double delta)
	{
		_moveStrategy?.Move(this, delta);
	}
}
