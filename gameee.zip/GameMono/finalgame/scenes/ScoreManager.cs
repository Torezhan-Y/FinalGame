using Godot;
using System.Collections.Generic;

public partial class ScoreManager : Node
{
	private List<Node> _observers = new List<Node>();
	public int Score { get; private set; } = 0;

	public void AddObserver(Node observer)
	{
		if (!_observers.Contains(observer))
			_observers.Add(observer);
	}

	public void Notify()
	{
		foreach (var observer in _observers)
		{
			if (observer.HasMethod("OnScoreUpdated"))
			{
				observer.Call("OnScoreUpdated", Score);
			}
		}
	}

	public void UpdateScore(int points)
	{
		Score += points;
		GD.Print($"Score: {Score}");

		Notify();

		if (Score >= 200)
		{
			GD.Print("Triggering transition to main2");

			var transition = GetNode<Transitionn>("/root/Transitionn");
			transition.FadeToScene("res://scenes/main2.tscn");
		}
	}
}
