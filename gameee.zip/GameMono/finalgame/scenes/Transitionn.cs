using Godot;
using System;

public partial class Transitionn : Node2D
{
	private Node2D fadeSprite;

	public override void _Ready()
	{
		fadeSprite = GetNode<Node2D>("FadeSprite");
		fadeSprite.Modulate = new Color(0, 0, 0, 1); // fully black

		FadeIn();
	}

	public void FadeIn(float duration = 0.5f)
	{
		var tween = GetTree().CreateTween();
		tween.TweenProperty(fadeSprite, "modulate:a", 0f, duration);
	}

	public void FadeOut(Action onFadeComplete, float duration = 0.5f)
	{
		var tween = GetTree().CreateTween();
		tween.TweenProperty(fadeSprite, "modulate:a", 1f, duration);
		tween.TweenCallback(Callable.From(onFadeComplete));
	}

	public void FadeToScene(string scenePath, float duration = 0.5f)
	{
		FadeOut(() =>
		{
			GetTree().ChangeSceneToFile(scenePath);
		}, duration);
	}
}
