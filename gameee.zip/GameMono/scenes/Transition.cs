using Godot;
using System;

public partial class Transition : CanvasLayer
{
	[Signal]
	public delegate void OnTransitionFinishedEventHandler();

	private ColorRect colorRect;
	private AnimationPlayer animationPlayer;

	public override void _Ready()
	{
		colorRect = GetNode<ColorRect>("ColorRect");
		animationPlayer = GetNode<AnimationPlayer>("AnimationPlayer");

		colorRect.Visible = true;
		animationPlayer.Play("fadeNormal"); // Fade in at start

		animationPlayer.AnimationFinished += OnAnimationFinished;
	}

	private void OnAnimationFinished(StringName animName)
	{
		if (animName == "fade")
		{
			EmitSignal(SignalName.OnTransitionFinished);
			animationPlayer.Play("fadeNormal");
		}
		else if (animName == "fadeNormal")
		{
			colorRect.Visible = false;
		}
	}

	public void StartTransition()
	{
		colorRect.Visible = true;
		animationPlayer.Play("fade");
	}
}
