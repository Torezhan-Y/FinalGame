using Godot;
using System;

public partial class Door : Area2D
{
	[Export]
	public string NextScenePath { get; set; } = "";

	private bool _isTransitioning = false;

	public override void _Ready()
	{
		Connect("body_entered", new Callable(this, nameof(OnBodyEntered)));
	}

	private void OnBodyEntered(Node body)
	{
		if (_isTransitioning) return;
		if (!(body is Player)) return; // Replace 'Player' if your player class is named differently

		_isTransitioning = true;
		var transition = GetTree().Root.GetNode<Transition>("Transition");
		transition.StartTransition();
		transition.OnTransitionFinished += OnTransitionFinished;
	}

	private void OnTransitionFinished()
	{
		var transition = GetTree().Root.GetNode<Transition>("Transition");
		transition.OnTransitionFinished -= OnTransitionFinished;
		GetTree().ChangeSceneToFile("res://scenes/main_2.tscn");
	}
}
