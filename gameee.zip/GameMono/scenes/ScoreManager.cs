using Godot;
using System.Collections.Generic;

public partial class ScoreManager : Node
{
	private List<Node> observers = new List<Node>();
	public int Score { get; private set; } = 0;

	public void AddObserver(Node observer)
	{
		observers.Add(observer);
	}

	public void Notify()
	{
		foreach (var observer in observers)
		{
			if (observer.HasMethod("OnScoreUpdated"))
			{
				observer.Call("OnScoreUpdated", Score);
			}
		}
	}

	public void UpdateScore(int points)
	{
		Score += points;
		GD.Print("Score: " + Score); // Confirm this shows up
		Notify();

		if (Score >= 200)
		{
			GD.Print("Triggering transition to main2");
var levelManager = (LevelManager)GetNode("/root/LevelManager");
levelManager.GoToLevel("main2", "default"); // adjust door tag as needed
}
	}
}
