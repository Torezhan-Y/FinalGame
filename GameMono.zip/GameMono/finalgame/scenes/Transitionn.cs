using Godot;
using System;

public class Transition : CanvasLayer
{
	private ColorRect _fadeRect;
	private Tween _tween;
	private float _fadeTime = 0.5f;
	private Action _callback;

	public override void _Ready()
	{
		// Create full-screen ColorRect for fade effect
		_fadeRect = new ColorRect();
		_fadeRect.Color = new Color(0, 0, 0, 0);
		_fadeRect.RectMinSize = GetViewportRect().Size;
		AddChild(_fadeRect);

		// Tween for animation
		_tween = new Tween();
		AddChild(_tween);

		_fadeRect.Show();
	}

	public void FadeOut(Action callback = null)
	{
		_callback = callback;

		_fadeRect.Color = new Color(0, 0, 0, 0);
		_fadeRect.Show();

		_tween.InterpolateProperty(
			_fadeRect, "color:a", 0f, 1f, _fadeTime,
			Tween.TransitionType.Linear, Tween.EaseType.InOut);
		_tween.Start();

		_tween.Connect("tween_completed", this, nameof(OnFadeOutComplete));
	}

	private void OnFadeOutComplete(object obj, NodePath key)
	{
		// Disconnect to avoid multiple calls
		_tween.Disconnect("tween_completed", this, nameof(OnFadeOutComplete));

		_callback?.Invoke();

		FadeIn();
	}

	private void FadeIn()
	{
		_tween.InterpolateProperty(
			_fadeRect, "color:a", 1f, 0f, _fadeTime,
			Tween.TransitionType.Linear, Tween.EaseType.InOut);
		_tween.Start();

		_tween.Connect("tween_completed", this, nameof(OnFadeInComplete));
	}

	private void OnFadeInComplete(object obj, NodePath key)
	{
		_tween.Disconnect("tween_completed", this, nameof(OnFadeInComplete));
		_fadeRect.Hide();
	}
}
