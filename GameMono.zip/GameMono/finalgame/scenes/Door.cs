using Godot;
using System;

public class Door : Area2D
{
	[Export] public NodePath ExitNodePath;
	[Export] public string NextScenePath;

	private Position2D _exitNode;
	private Player _player;
	private bool _isTransitioning = false;

	public override void _Ready()
	{
		_exitNode = GetNode<Position2D>(ExitNodePath);
	}

	private void OnBodyEntered(Node body)
	{
		if (_isTransitioning) return;

		_player = body as Player;
		if (_player == null) return;

		_isTransitioning = true;
		_player.SetProcess(false); // Your player should support this

		Vector2 exitPos = _exitNode.GlobalPosition;
		Tween tween = new Tween();
		AddChild(tween);
		tween.InterpolateProperty(_player, "global_position", _player.GlobalPosition, exitPos, 0.5f);
		tween.Start();
		tween.Connect("tween_completed", this, nameof(OnPlayerReachedExit));
	}

	private void OnPlayerReachedExit(object obj, NodePath key)
	{
		SceneTransition.FadeOut(() =>
		{
			GetTree().ChangeScene(NextScenePath);
		});
	}
}
