using Godot;

public partial class Player : CharacterBody2D
{
 public IPlayerState State { get; set; } = new IdleState();

 private AnimatedSprite2D _animatedSprite;
 private AudioStreamPlayer _jumpSound;

 public override void _Ready()
 {
  _animatedSprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
  _jumpSound = GetNode<AudioStreamPlayer>("JumpSound");
 }

 public void PlayAnimation(string animName)
 {
  _animatedSprite?.Play(animName);
 }

 public override void _PhysicsProcess(double delta)
 {
  // Используем явно Godot.Vector2, чтобы избежать конфликтов с System.Numerics.Vector2
  Godot.Vector2 velocity = Velocity;

  // Добавляем гравитацию
  velocity.Y += 5200 * (float)delta;

  // Обновляем скорость
  Velocity = velocity;

  // Обработка состояния
  State?.HandleInput(this);
  State?.Update(this, (float)delta);

  // Движение и столкновения
  MoveAndSlide();
 }

 // Вспомогательный метод для прыжка и звука
 public void Jump()
 {
  Godot.Vector2 velocity = Velocity;
  velocity.Y = -1800;  // JUMP_SPEED
  Velocity = velocity;

  _jumpSound?.Play();
 }
}
