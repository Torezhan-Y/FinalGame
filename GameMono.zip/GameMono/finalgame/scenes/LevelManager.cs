using Godot;
using System;
using System.Threading.Tasks;

public partial class LevelManager : Node
{
	[Signal]
	public delegate void OnTriggerPlayerSpawnEventHandler(Vector2 position, string direction);

	private const string MainPath = "res://scenes/main.tscn";
	private const string Main2Path = "res://scenes/main_2.tscn";

	private string spawnDoorTag;

	public async void GoToLevel(string levelTag, string destinationTag)
	{
		PackedScene sceneToLoad = null;

		switch (levelTag)
		{
			case "main":
				sceneToLoad = GD.Load<PackedScene>(MainPath);
				break;
			case "main2":
				sceneToLoad = GD.Load<PackedScene>(Main2Path);
				break;
			default:
				GD.PrintErr("Invalid level tag: " + levelTag);
				return;
		}

		if (sceneToLoad != null)
		{
			GD.Print("Getting Transition node from autoload...");
			var transitionScreen = (Transition)GetNode("/root/Transition");

			GD.Print("Starting transition...");
			transitionScreen.StartTransition();

			GD.Print("Waiting for transition to finish...");
			await ToSignal(transitionScreen, "OnTransitionFinished");

			GD.Print("Transition finished. Changing scene.");
			spawnDoorTag = destinationTag;
			GetTree().ChangeSceneToPacked(sceneToLoad);
		}
		else
		{
			GD.PrintErr("Scene failed to load.");
		}
	}

	public void TriggerPlayerSpawn(Vector2 position, string direction)
	{
		EmitSignal(SignalName.OnTriggerPlayerSpawn, position, direction);
	}
}
